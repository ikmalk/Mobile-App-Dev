package com.example.mobiledev;

import java.io.Serializable;
import androidx;

@Entity(tablename = "notes")
public class Note implements Serializable {



}
